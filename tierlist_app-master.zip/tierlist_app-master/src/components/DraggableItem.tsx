import React from 'react';
import { useDraggable } from '@dnd-kit/core';
import type { TierItem } from '../store/tierStore';

interface DraggableItemProps {
  item: TierItem;
}

export const DraggableItem: React.FC<DraggableItemProps> = ({ item }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    isDragging,
  } = useDraggable({
    id: item.id,
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
  } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={`
        tier-item cursor-grab active:cursor-grabbing
        w-16 h-16 bg-white rounded-lg shadow-md border-2 border-gray-200
        flex items-center justify-center overflow-hidden
        ${isDragging ? 'opacity-50 z-50' : 'hover:shadow-lg'}
      `}
      title={item.name}
    >
      <img
        src={item.image}
        alt={item.name}
        className="w-full h-full object-contain"
        draggable={false}
      />
    </div>
  );
}; 