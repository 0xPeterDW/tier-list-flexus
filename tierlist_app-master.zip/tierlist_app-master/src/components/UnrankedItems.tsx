import React from 'react';
import { useDroppable } from '@dnd-kit/core';
import type { TierItem } from '../store/tierStore';
import { DraggableItem } from './DraggableItem';

interface UnrankedItemsProps {
  items: TierItem[];
}

export const UnrankedItems: React.FC<UnrankedItemsProps> = ({ items }) => {
  const {
    isOver,
    setNodeRef,
  } = useDroppable({
    id: 'unranked',
  });

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
      <h3 className="text-lg font-semibold mb-4 text-gray-800">
        🎮 Éléments non classés
      </h3>
      <div
        ref={setNodeRef}
        className={`
          tier-row flex flex-wrap gap-3 min-h-24 p-4 rounded-lg
          ${isOver ? 'bg-blue-50 border-blue-300 border-2' : 'border-2 border-dashed border-gray-300'}
          ${items.length === 0 ? 'border-dashed' : 'border-solid border-gray-200'}
          transition-all duration-200
        `}
      >
        {items.length === 0 ? (
          <div className="flex items-center justify-center w-full text-gray-400 text-sm">
            🎉 Tous les éléments sont classés !
          </div>
        ) : (
          items.map((item) => (
            <DraggableItem key={item.id} item={item} />
          ))
        )}
      </div>
    </div>
  );
}; 