import React from 'react';
import { useDroppable } from '@dnd-kit/core';
import type { TierRow as TierRowType } from '../store/tierStore';
import { useTierStore } from '../store/tierStore';
import { DraggableItem } from './DraggableItem';
import { Icon } from './Icon';

interface TierRowProps {
  tier: TierRowType;
}

export const TierRow: React.FC<TierRowProps> = ({ tier }) => {
  const { changeTierColor } = useTierStore();
  const {
    isOver,
    setNodeRef,
  } = useDroppable({
    id: tier.id,
  });

  const handleColorChange = () => {
    changeTierColor(tier.id);
  };

  return (
    <div className="flex bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200">
      {/* Tier Label with Color Change Button */}
      <div className="flex items-center">
        <div className={`
          ${tier.color} w-28 flex items-center justify-center
          text-white font-bold text-3xl shadow-sm
        `}>
          {tier.label}
        </div>
        <button
          onClick={handleColorChange}
          className="p-3 hover:bg-gray-100 transition-colors duration-200 border-r border-gray-200 group"
          title="Changer la couleur"
        >
          <Icon 
            icon="Palette" 
            className="text-gray-500 group-hover:text-gray-700 transition-colors duration-200" 
            size={20}
          />
        </button>
      </div>
      
      {/* Items Container */}
      <div
        ref={setNodeRef}
        className={`
          tier-row flex-1 flex flex-wrap gap-3 p-4 min-h-24
          ${isOver ? 'bg-blue-50 border-blue-300' : ''}
          ${tier.items.length === 0 ? 'border-dashed border-2 border-gray-300' : ''}
          transition-all duration-200
        `}
      >
        {tier.items.length === 0 ? (
          <div className="flex items-center justify-center w-full text-gray-400 text-sm">
            Glissez des éléments ici
          </div>
        ) : (
          tier.items.map((item) => (
            <DraggableItem key={item.id} item={item} />
          ))
        )}
      </div>
    </div>
  );
}; 