import React from 'react';

interface PaletteIconProps {
  className?: string;
  size?: number | string;
  color?: string;
}

export const PaletteIcon: React.FC<PaletteIconProps> = ({ 
  className = '', 
  size = 20, 
  color = 'currentColor',
  ...props 
}) => (
  <svg
    className={className}
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path 
      d="M12 2C13.3132 2 14.6136 2.25866 15.8268 2.7612C17.0401 3.26375 18.1425 4.00035 19.0711 4.92893C19.9997 5.85752 20.7362 6.95991 21.2388 8.17317C21.7413 9.38642 22 10.6868 22 12C22 13.3132 21.7413 14.6136 21.2388 15.8268C20.7362 17.0401 19.9997 18.1425 19.0711 19.0711C18.1425 19.9997 17.0401 20.7362 15.8268 21.2388C14.6136 21.7413 13.3132 22 12 22C9.61305 22 7.32387 21.0518 5.63604 19.364C3.94821 17.6761 3 15.3869 3 13C3 10.6131 3.94821 8.32387 5.63604 6.63604C7.32387 4.94821 9.61305 4 12 4V2Z" 
      fill={color}
    />
    <circle cx="8.5" cy="10.5" r="1.5" fill="white" />
    <circle cx="15.5" cy="10.5" r="1.5" fill="white" />
    <circle cx="12" cy="7.5" r="1.5" fill="white" />
    <circle cx="8.5" cy="15.5" r="1.5" fill="white" />
    <circle cx="15.5" cy="15.5" r="1.5" fill="white" />
  </svg>
); 