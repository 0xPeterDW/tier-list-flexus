import React from 'react';
import type { HTMLAttributes } from 'react';
import { icons } from './icons';
import type { IconName } from './icons';

interface IconProps extends Omit<HTMLAttributes<HTMLDivElement>, 'color'> {
  icon: IconName;
  className?: string;
  size?: number | string;
  color?: string;
}

export const Icon: React.FC<IconProps> = ({ 
  icon, 
  className = '', 
  size = 20,
  color = 'currentColor',
  ...rest 
}) => {
  const IconComponent = icons[icon];

  if (!IconComponent) return null;

  return (
    <IconComponent 
      className={className}
      size={size}
      color={color}
      {...rest}
    />
  );
}; 