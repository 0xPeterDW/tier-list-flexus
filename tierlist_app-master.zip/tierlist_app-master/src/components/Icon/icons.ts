import { PaletteIcon } from './PaletteIcon';

export const icons = {
  Palette: PaletteIcon,
};

export type IconName = keyof typeof icons; 