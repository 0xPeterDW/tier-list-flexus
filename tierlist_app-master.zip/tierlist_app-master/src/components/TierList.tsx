import React from 'react';
import {
  DndContext,
  DragOverlay,
  closestCenter,
} from '@dnd-kit/core';
import type {
  DragEndEvent,
  DragStartEvent,
} from '@dnd-kit/core';
import { useTierStore } from '../store/tierStore';
import { TierRow } from './TierRow';
import { UnrankedItems } from './UnrankedItems';
import { DraggableItem } from './DraggableItem';

export const TierList: React.FC = () => {
  const { tiers, unrankedItems, moveItem, resetTiers } = useTierStore();
  const [activeId, setActiveId] = React.useState<string | null>(null);

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (!over) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    // Find source tier
    let sourceTierId = 'unranked';
    for (const tier of tiers) {
      if (tier.items.some(item => item.id === activeId)) {
        sourceTierId = tier.id;
        break;
      }
    }

    // If dropping on same tier, do nothing
    if (sourceTierId === overId) return;

    // Move item
    moveItem(activeId, sourceTierId, overId);
  };

  const activeItem = React.useMemo(() => {
    if (!activeId) return null;
    
    const item = unrankedItems.find(item => item.id === activeId);
    if (item) return item;

    for (const tier of tiers) {
      const item = tier.items.find(item => item.id === activeId);
      if (item) return item;
    }
    
    return null;
  }, [activeId, unrankedItems, tiers]);

  return (
    <div className="bg-gray-100 py-6">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900">Créateur de Tier List</h1>
            <p className="text-gray-600 mt-2">Glissez et déposez les éléments pour créer votre tier list</p>
          </div>
          <button
            onClick={resetTiers}
            className="px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-medium transition-colors duration-200 shadow-sm"
          >
            Réinitialiser
          </button>
        </div>

        <DndContext
          collisionDetection={closestCenter}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          {/* Tier Rows */}
          <div className="mb-8 space-y-4">
            {tiers.map((tier) => (
              <TierRow key={tier.id} tier={tier} />
            ))}
          </div>

          {/* Unranked Items */}
          <UnrankedItems items={unrankedItems} />

          {/* Drag Overlay */}
          <DragOverlay>
            {activeItem ? <DraggableItem item={activeItem} /> : null}
          </DragOverlay>
        </DndContext>
      </div>
    </div>
  );
}; 