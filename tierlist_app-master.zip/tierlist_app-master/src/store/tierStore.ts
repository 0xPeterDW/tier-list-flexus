import { create } from 'zustand';

export interface TierItem {
  id: string;
  name: string;
  image: string;
}

export interface TierRow {
  id: string;
  label: string;
  color: string;
  items: TierItem[];
}

interface TierStore {
  tiers: TierRow[];
  unrankedItems: TierItem[];
  moveItem: (itemId: string, sourceTierId: string, targetTierId: string, targetIndex?: number) => void;
  addItem: (item: TierItem) => void;
  removeItem: (itemId: string) => void;
  resetTiers: () => void;
  changeTierColor: (tierId: string) => void;
}

// Liste des couleurs disponibles pour les tiers
const tierColors = [
  'bg-red-500',
  'bg-orange-500', 
  'bg-yellow-500',
  'bg-green-500',
  'bg-blue-500',
  'bg-purple-500',
  'bg-pink-500',
  'bg-indigo-500',
  'bg-teal-500',
  'bg-gray-500',
  'bg-red-400',
  'bg-orange-400',
  'bg-yellow-400',
  'bg-green-400',
  'bg-blue-400',
  'bg-purple-400',
  'bg-pink-400',
  'bg-indigo-400',
  'bg-teal-400',
  'bg-gray-400',
];

const defaultTiers: TierRow[] = [
  { id: 'tier-s', label: 'S', color: 'bg-tier-s', items: [] },
  { id: 'tier-a', label: 'A', color: 'bg-tier-a', items: [] },
  { id: 'tier-b', label: 'B', color: 'bg-tier-b', items: [] },
  { id: 'tier-c', label: 'C', color: 'bg-tier-c', items: [] },
  { id: 'tier-d', label: 'D', color: 'bg-tier-d', items: [] },
];

const defaultItems: TierItem[] = [
  { id: '1', name: 'Pikachu', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png' },
  { id: '2', name: 'Charizard', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/6.png' },
  { id: '3', name: 'Blastoise', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/9.png' },
  { id: '4', name: 'Venusaur', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/3.png' },
  { id: '5', name: 'Mewtwo', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/150.png' },
  { id: '6', name: 'Mew', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/151.png' },
  { id: '7', name: 'Lucario', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/448.png' },
  { id: '8', name: 'Garchomp', image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/445.png' },
];

export const useTierStore = create<TierStore>((set, get) => ({
  tiers: defaultTiers,
  unrankedItems: defaultItems,

  moveItem: (itemId, sourceTierId, targetTierId, targetIndex) => {
    const state = get();
    const sourceItems = sourceTierId === 'unranked' 
      ? state.unrankedItems 
      : state.tiers.find(t => t.id === sourceTierId)?.items || [];
    
    const item = sourceItems.find(item => item.id === itemId);
    if (!item) return;

    // Remove item from source
    const newState = { ...state };
    if (sourceTierId === 'unranked') {
      newState.unrankedItems = state.unrankedItems.filter(i => i.id !== itemId);
    } else {
      newState.tiers = state.tiers.map(tier => 
        tier.id === sourceTierId 
          ? { ...tier, items: tier.items.filter(i => i.id !== itemId) }
          : tier
      );
    }

    // Add item to target
    if (targetTierId === 'unranked') {
      const insertIndex = targetIndex !== undefined ? targetIndex : newState.unrankedItems.length;
      newState.unrankedItems.splice(insertIndex, 0, item);
    } else {
      newState.tiers = newState.tiers.map(tier => 
        tier.id === targetTierId 
          ? { 
              ...tier, 
              items: targetIndex !== undefined 
                ? [...tier.items.slice(0, targetIndex), item, ...tier.items.slice(targetIndex)]
                : [...tier.items, item]
            }
          : tier
      );
    }

    set(newState);
  },

  addItem: (item) => {
    set(state => ({
      unrankedItems: [...state.unrankedItems, item]
    }));
  },

  removeItem: (itemId) => {
    set(state => ({
      tiers: state.tiers.map(tier => ({
        ...tier,
        items: tier.items.filter(item => item.id !== itemId)
      })),
      unrankedItems: state.unrankedItems.filter(item => item.id !== itemId)
    }));
  },

  changeTierColor: (tierId) => {
    set(state => {
      const tierIndex = state.tiers.findIndex(tier => tier.id === tierId);
      if (tierIndex === -1) return state;

      const currentColorIndex = tierColors.indexOf(state.tiers[tierIndex].color);
      const nextColorIndex = (currentColorIndex + 1) % tierColors.length;
      const newColor = tierColors[nextColorIndex];

      const newTiers = [...state.tiers];
      newTiers[tierIndex] = { ...newTiers[tierIndex], color: newColor };

      return { ...state, tiers: newTiers };
    });
  },

  resetTiers: () => {
    set({
      tiers: defaultTiers,
      unrankedItems: defaultItems
    });
  }
})); 