import { Layout } from './layout';
import { TierList } from './components/TierList';

function App() {
  return (
    <Layout>
      <TierList />
    </Layout>
  );
}

export default App;
